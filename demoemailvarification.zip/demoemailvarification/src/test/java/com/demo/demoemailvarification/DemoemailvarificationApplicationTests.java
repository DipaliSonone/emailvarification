package com.demo.demoemailvarification;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoemailvarificationApplicationTests {

	@Test
	void contextLoads() {
	}

}
