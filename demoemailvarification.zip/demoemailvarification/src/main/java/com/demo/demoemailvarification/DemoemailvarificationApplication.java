package com.demo.demoemailvarification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoemailvarificationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoemailvarificationApplication.class, args);
	}

}
